package com.example.weekonetutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etTitle;
    EditText etPrice;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        etTitle=findViewById(R.id.titlename);
        
        etPrice=findViewById(R.id.editTextTextPersonName8);

    }



    /** Called when the user touches the button*/
    public void showToast(View view) {
        String Titlemain= etTitle.getText().toString().trim();
        String Priceproduct=etPrice.getText().toString().trim();
        Toast.makeText(getApplicationContext(),"The name and price are the following: " + Titlemain + " " + "," +" " +Priceproduct , Toast.LENGTH_SHORT).show();
    }

    public void clearFields(View view) {
        EditText titlename =findViewById(R.id.titlename);
        titlename.getText().clear();

        EditText identificationnum =findViewById(R.id.identificationnumb);
        identificationnum.getText().clear();

        EditText isbnnumb =findViewById(R.id.isbnnumb);
        isbnnumb.getText().clear();

        EditText authorname =findViewById(R.id.authorname);
        authorname.getText().clear();

        EditText descriptionofbook =findViewById(R.id.descriptionofbook);
        descriptionofbook.getText().clear();

        EditText editTextTextPersonName8 =findViewById(R.id.editTextTextPersonName8);
        editTextTextPersonName8.getText().clear();






    }

/**  public void start (View view) {
        String Titlemain = etTitle.getText().toString().trim();
        Toast.makeText(getApplicationContext(), "Hello Javatpoint" + Titlemain, Toast.LENGTH_SHORT).show();*/


    }
